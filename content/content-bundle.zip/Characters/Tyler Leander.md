___


## Personal Information
___
- Son of [[Arthur Leander]]
- About seven or eight years old
- 
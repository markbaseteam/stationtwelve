___




## Personal Information
___
- Aspiring paramedic
- Ex- entertainment journalist
- Girlfriend [[Laura]] ([[Jeevan Chaudhary and Laura]])
- 

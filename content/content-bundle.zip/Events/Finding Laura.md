____

(I)
- As [[Jeevan Chaudhary]] and [[Kirsten Raymonde]] try to find [[Tanya]], they sit together and have a little chat about purpose and acting. [[Jeevan Chaudhary and Kirsten Raymonde]]
	- When Tanya comes to pick Kirsten up, she barely glances at Jeevan.
		- They dissapear into the crowd.
	- Jeevan Half expects [[Laura]] to be where he left her.
		- Jeevan looks everywhere for Laura, but cannot find her at [[Elgin Theatre]]. Jeevan concludes that Laura has left and leaves as well from her blue coat.
		- Jeevan sends Laura a voicemail.

(II)
- It is snowing in [[Toronto]]
	-  Jeevan finds that paparazzi is outside waiting by the door.
		- Find out that Jeevan used to also be a paparazzo
		- Find out that [[Arthur Leander]] was in a gladitorial divorce with a model/actress who cheated on him. 
		- Jeevan talks about his current life with a paparazzo.
	- Find out that Arthur was classified dead from exhaustion and dehydration
		- Some suits and medics are laughing it off.
			- Jeevan feels "Guiltily alive"
	- Arthur slips away pretending to be on his phone

(III)
- Find out why Jeevan wanted to be a paramedic
	- Step forwards in the scenes of danger.
	- Jeevan feels a sense of purpose. 
- Jeevan gets a text from laura, saying that she does not feel well and that she wishes for Jeevan to buy some milk.([[Insignificance]] )
	- Jeevan feels the purpose leave him.([[Relationships]]) 
	- Find that Jeevan and Laura always fight. [[Calm Before The Storm]]


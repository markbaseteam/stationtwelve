___
Details the relationship between [[Jeevan Chaudhary]] and [[Arthur Leander]]


## Relationship Details
___
- Jeevan once interviewed Arthur in Los Angeles years ago
	- 
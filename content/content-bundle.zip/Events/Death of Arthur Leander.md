___

(I)
- At the beginning of the scene, [[Arthur Leander]] is performing [[King Lear]] and  during winter at [[Elgin Theatre]] in [[Toronto]]. ([[Death and Chaos]])
	- King lear is going nutso at this point in the scene (Act 4, Scene 6), he goes into a monologue about some stuff
		- Similar to in this scene where Arthur Leander is going crazy but in real life (seizure and dies).
		- Justl like how Gloucester dies In King lear, he also dies in the book later on the side walk.

(II)
- As [[Jeevan Chaudhary]] rushes up to the stage to help Arthur, he gets stopped by security guards at first. ([[Jeevan Chaudhary and Arthur Leander]])
	- Jeevan has no luck, and meets [[Walter Jacobi]]. ([[Jeevan Chaudhary and Walter Jacobi]])
	- Snow begins to fall as they are all on stage
		- The snow does not stop until a while after
	- Jeevan gets a sense that he is being watched from above
		- Immediately after, Jeevan feels like his role is finished (not being watched anymore)
		- Goes to find [[Laura]]
			- Thinks that his actions will win the praise of Laura. ([[Relationships]])
			- Finds [[Kirsten Raymonde]] crying. [[Jeevan Chaudhary and Kirsten Raymonde]] 

(III)
- While the medics are trying to resuscitate Arthur, Jeevan and Kirsten talk
	- Uncomfortable parallel motion going on while the medics are doing their job and Jeevan talking
	- Laura cries while looking at a dying Arthur.
	- The conversation continues while Arthur dies



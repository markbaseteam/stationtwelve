___
[[Death of Arthur Leander]]
[[Finding Laura]]




## Synopsis
___



## Questions for Chapter 1
___

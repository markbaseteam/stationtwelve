___


## Personal Information
___
- Arthur Leander is a well established actor for the [[Traveling Symphony]]
	- Loved acting the best in the world
	- Waited his entire life to play [[King Lear]].
- Had an affair with [[Tanya]]
	- Had three other affairs before [[Tanya]]
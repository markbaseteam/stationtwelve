___
(I)
- Gloucester, Cordelia, some others drink at a bar discussing the death of [[Arthur Leander]] in [[Elgin Theatre]]. [[Relationships]].
	- Find out that Arthur had a son named [[Tyler Leander]]
		- Tyler is about seven or eight.
	- Find out that Arthur had three wives, likely his fault. 
	- [[Tanya]] is brought up, and everybody but the producer is in on it.
	- They all die three weeks later.

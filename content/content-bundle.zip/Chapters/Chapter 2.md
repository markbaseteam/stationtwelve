___



## Synopsis 
___



## Questions for Chapter 2
___

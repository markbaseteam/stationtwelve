___




## Personal Information
___
- Kirsten raymonde is an actor for the [[Traveling Symphony]]
- Kirsten is eight years old
- Like [[Arthur Leander]], acting is the thing that she loves most in the world.



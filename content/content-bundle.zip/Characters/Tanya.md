___



## Personal Information
___
- The wrangler for the child actors at [[Traveling Symphony]].
	- Takes care of [[Kirsten Raymonde]]
- Had an affair with [[Arthur Leander]].

